package com.example.localization

import android.content.Context
import android.content.ContextWrapper
import android.content.res.AssetManager
import android.content.res.Configuration
import android.content.res.Resources
import androidx.annotation.ArrayRes
import androidx.annotation.StringRes
import com.example.R

class LocalizedContextWrapper(
    base: Context,
    private val localizedResources: Resources,
) : ContextWrapper(base) {

    override fun getResources(): Resources = localizedResources

    override fun getAssets(): AssetManager = localizedResources.assets

    override fun createConfigurationContext(overrideConfiguration: Configuration): Context =
        baseContext.createConfigurationContext(overrideConfiguration)
}

object Dera3StringResources {

    fun unwrapBaseContext(context: Context): Context {
        var current = context
        while (current is LocalizedContextWrapper) {
            current = current.baseContext
        }
        return current
    }

    fun localizedConfiguration(baseContext: Context, language: AppLanguage): Configuration {
        val unwrapped = unwrapBaseContext(baseContext)
        val locale = LocalizationManager.localeFor(language)
        return Configuration(unwrapped.resources.configuration).apply {
            setLocale(locale)
            setLayoutDirection(locale)
        }
    }

    fun localizedContext(baseContext: Context, language: AppLanguage): Context {
        val unwrapped = unwrapBaseContext(baseContext)
        val config = localizedConfiguration(unwrapped, language)
        val configContext = unwrapped.createConfigurationContext(config)
        return LocalizedContextWrapper(unwrapped, configContext.resources)
    }

    fun getString(
        context: Context,
        language: AppLanguage,
        @StringRes resId: Int,
        vararg formatArgs: Any,
    ): String {
        val localized = localizedContext(context, language)
        return if (formatArgs.isEmpty()) {
            localized.getString(resId)
        } else {
            localized.getString(resId, *formatArgs)
        }
    }

    fun getStringArray(
        context: Context,
        language: AppLanguage,
        @ArrayRes resId: Int,
    ): List<String> {
        val localized = localizedContext(context, language)
        return localized.resources.getStringArray(resId).toList()
    }

    fun load(context: Context, language: AppLanguage): Dera3Strings {
        val localized = localizedContext(context, language)
        return fromResources(localized.resources)
    }

    fun fromContext(context: Context): Dera3Strings = fromResources(context.resources)

    fun fromResources(res: Resources): Dera3Strings = Dera3Strings(
        appName = res.getString(R.string.app_name),
        appTagline = res.getString(R.string.app_tagline),
        appMission = res.getString(R.string.app_mission),
        darkMode = res.getString(R.string.dark_mode),
        lightMode = res.getString(R.string.light_mode),
        languageLabel = res.getString(R.string.language_label),
        switchLanguageBtn = res.getString(R.string.switch_language_btn),
        signInWithGoogle = res.getString(R.string.sign_in_with_google),
        createAccountTitle = res.getString(R.string.create_account_title),
        createAccountSubtitle = res.getString(R.string.create_account_subtitle),
        fullNameLabel = res.getString(R.string.full_name_label),
        emailLabel = res.getString(R.string.email_label),
        phoneLabel = res.getString(R.string.phone_label),
        createAccountBtn = res.getString(R.string.create_account_btn),
        otpTitle = res.getString(R.string.otp_title),
        otpSubtitle = res.getString(R.string.otp_subtitle),
        otpHint = res.getString(R.string.otp_hint),
        otpDemoNote = res.getString(R.string.otp_demo_note),
        verifyBtn = res.getString(R.string.verify_btn),
        otpError = res.getString(R.string.otp_error),
        securityScoreTitle = res.getString(R.string.security_score_title),
        securityScoreOutOf = res.getString(R.string.security_score_out_of),
        scoreLowAdvice = res.getString(R.string.score_low_advice),
        scoreMidAdvice = res.getString(R.string.score_mid_advice),
        scoreHighAdvice = res.getString(R.string.score_high_advice),
        allShieldsTitle = res.getString(R.string.all_shields_title),
        offlineBadge = res.getString(R.string.offline_badge),
        onlineAiBadge = res.getString(R.string.online_ai_badge),
        disabledByAdmin = res.getString(R.string.disabled_by_admin),
        ptsEarnedFormat = res.getString(R.string.pts_earned_format),
        ptsFormat = res.getString(R.string.pts_format),
        settingsTitle = res.getString(R.string.settings_title),
        notificationsLabel = res.getString(R.string.notifications_label),
        soundLabel = res.getString(R.string.sound_label),
        signOutLabel = res.getString(R.string.sign_out_label),
        adminPanelTitle = res.getString(R.string.admin_panel_title),
        adminPanelBtn = res.getString(R.string.admin_panel_btn),
        returnToAdmin = res.getString(R.string.return_to_admin),
        viewingAsUserFormat = res.getString(R.string.viewing_as_user_format),
        totalUsersLabel = res.getString(R.string.total_users_label),
        searchUsersHint = res.getString(R.string.search_users_hint),
        enterAsUserBtn = res.getString(R.string.enter_as_user_btn),
        shieldsControlTitle = res.getString(R.string.shields_control_title),
        shieldEnabled = res.getString(R.string.shield_enabled),
        shieldDisabled = res.getString(R.string.shield_disabled),
        backLabel = res.getString(R.string.back_label),
        copyBtn = res.getString(R.string.copy_btn),
        copiedToast = res.getString(R.string.copied_toast),
        scanBtn = res.getString(R.string.scan_btn),
        checkBtn = res.getString(R.string.check_btn),
        shieldTitles = res.getStringArray(R.array.shield_titles).toList(),
        shieldSubtitles = res.getStringArray(R.array.shield_subtitles).toList(),
        wifiInputHint = res.getString(R.string.wifi_input_hint),
        wifiDangerResult = res.getString(R.string.wifi_danger_result),
        wifiSafeResult = res.getString(R.string.wifi_safe_result),
        wifiChecks = res.getStringArray(R.array.wifi_checks).toList(),
        wifiTip = res.getString(R.string.wifi_tip),
        whatsappGuide = res.getString(R.string.whatsapp_guide),
        whatsappChecks = res.getStringArray(R.array.whatsapp_checks).toList(),
        whatsappCheckedBtn = res.getString(R.string.whatsapp_checked_btn),
        breachInputHint = res.getString(R.string.breach_input_hint),
        breachGuideResult = res.getString(R.string.breach_guide_result),
        breachOpenSiteBtn = res.getString(R.string.breach_open_site_btn),
        breachChecks = res.getStringArray(R.array.breach_checks).toList(),
        privacyGuide = res.getString(R.string.privacy_guide),
        privacyChecks = res.getStringArray(R.array.privacy_checks).toList(),
        elderlyEmergencyHint = res.getString(R.string.elderly_emergency_hint),
        elderlySaveBtn = res.getString(R.string.elderly_save_btn),
        elderlySavedMsg = res.getString(R.string.elderly_saved_msg),
        elderlyReadyMessage = res.getString(R.string.elderly_ready_message),
        elderlyCopyMsgBtn = res.getString(R.string.elderly_copy_msg_btn),
        elderlyGuide = res.getString(R.string.elderly_guide),
        linkInputHint = res.getString(R.string.link_input_hint),
        linkScanBtn = res.getString(R.string.link_scan_btn),
        linkDangerVerdict = res.getString(R.string.link_danger_verdict),
        linkSafeVerdict = res.getString(R.string.link_safe_verdict),
        linkCheckLabels = res.getStringArray(R.array.link_check_labels).toList(),
        honeypotDesc = res.getString(R.string.honeypot_desc),
        honeypotActivateBtn = res.getString(R.string.honeypot_activate_btn),
        honeypotSimulateBtn = res.getString(R.string.honeypot_simulate_btn),
        honeypotActiveBadge = res.getString(R.string.honeypot_active_badge),
        honeypotLogsTitle = res.getString(R.string.honeypot_logs_title),
        honeypotEmptyLogs = res.getString(R.string.honeypot_empty_logs),
        passwordInputHint = res.getString(R.string.password_input_hint),
        passwordCheckBtn = res.getString(R.string.password_check_btn),
        passwordGenerateBtn = res.getString(R.string.password_generate_btn),
        passwordWeak = res.getString(R.string.password_weak),
        passwordMedium = res.getString(R.string.password_medium),
        passwordStrong = res.getString(R.string.password_strong),
        passwordGeneratedLabel = res.getString(R.string.password_generated_label),
        fakeAppInputHint = res.getString(R.string.fake_app_input_hint),
        fakeAppDanger = res.getString(R.string.fake_app_danger),
        fakeAppSafe = res.getString(R.string.fake_app_safe),
        fakeAppGuide = res.getString(R.string.fake_app_guide),
        scamCallInputHint = res.getString(R.string.scam_call_input_hint),
        scamCallEgyptian = res.getString(R.string.scam_call_egyptian),
        scamCallForeign = res.getString(R.string.scam_call_foreign),
        scamCallGuide = res.getString(R.string.scam_call_guide),
        aiInputHint = res.getString(R.string.ai_input_hint),
        aiExampleHint = res.getString(R.string.ai_example_hint),
        aiAskBtn = res.getString(R.string.ai_ask_btn),
        aiQuickQuestions = res.getStringArray(R.array.ai_quick_questions).toList(),
        aiOfflineNotice = res.getString(R.string.ai_offline_notice),
        aiPoweredBy = res.getString(R.string.ai_powered_by),
        noResultsFound = res.getString(R.string.no_results_found),
        badgesTitle = res.getString(R.string.badges_title),
        badgeUnlockedLabel = res.getString(R.string.badge_unlocked_label),
        badgeLockedTargetFormat = res.getString(R.string.badge_locked_target_format),
        badgeNewCelebrationFormat = res.getString(R.string.badge_new_celebration_format),
        threatScannerTitle = res.getString(R.string.threat_scanner_title),
        threatScannerSubtitle = res.getString(R.string.threat_scanner_subtitle),
        threatStatusCritical = res.getString(R.string.threat_status_critical),
        threatStatusModerate = res.getString(R.string.threat_status_moderate),
        threatStatusProtected = res.getString(R.string.threat_status_protected),
        threatProtectedShieldsLabel = res.getString(R.string.threat_protected_shields_label),
        threatOpenRisksLabel = res.getString(R.string.threat_open_risks_label),
        threatPausedShieldsLabel = res.getString(R.string.threat_paused_shields_label),
        threatScanNowBtn = res.getString(R.string.threat_scan_now_btn),
        threatScanningLabel = res.getString(R.string.threat_scanning_label),
        threatScanCompleteAllSafe = res.getString(R.string.threat_scan_complete_all_safe),
        threatScanCompleteFoundFormat = res.getString(R.string.threat_scan_complete_found_format),
        threatNextActionFormat = res.getString(R.string.threat_next_action_format),
        phishingAlertsTitle = res.getString(R.string.phishing_alerts_title),
        phishingLiveBannerTag = res.getString(R.string.phishing_live_banner_tag),
        phishingAlertsSubtitle = res.getString(R.string.phishing_alerts_subtitle),
        phishingInspectBtn = res.getString(R.string.phishing_inspect_btn),
        phishingDismissBtn = res.getString(R.string.phishing_dismiss_btn),
        phishingViewAllBtn = res.getString(R.string.phishing_view_all_btn),
        phishingMarkReadBtn = res.getString(R.string.phishing_mark_read_btn),
        phishingMarkAllReadBtn = res.getString(R.string.phishing_mark_all_read_btn),
        phishingReadBadge = res.getString(R.string.phishing_read_badge),
        phishingSourceAdvisory = res.getString(R.string.phishing_source_advisory),
        phishingSourceDetected = res.getString(R.string.phishing_source_detected),
        phishingEmptyTitle = res.getString(R.string.phishing_empty_title),
        phishingEmptySubtitle = res.getString(R.string.phishing_empty_subtitle),
        phishingSeverityCritical = res.getString(R.string.phishing_severity_critical),
        phishingSeverityHigh = res.getString(R.string.phishing_severity_high),
        phishingSeverityMedium = res.getString(R.string.phishing_severity_medium),
        phishingOpenShieldBtn = res.getString(R.string.phishing_open_shield_btn),
        phishingToastNewFormat = res.getString(R.string.phishing_toast_new_format),
        adminAlertsSectionTitle = res.getString(R.string.admin_alerts_section_title),
        adminAlertsSectionSubtitle = res.getString(R.string.admin_alerts_section_subtitle),
        adminAlertTitleArHint = res.getString(R.string.admin_alert_title_ar_hint),
        adminAlertTitleEnHint = res.getString(R.string.admin_alert_title_en_hint),
        adminAlertMsgArHint = res.getString(R.string.admin_alert_msg_ar_hint),
        adminAlertMsgEnHint = res.getString(R.string.admin_alert_msg_en_hint),
        adminAlertIndicatorHint = res.getString(R.string.admin_alert_indicator_hint),
        adminPublishAlertBtn = res.getString(R.string.admin_publish_alert_btn),
        adminQuickTemplatesLabel = res.getString(R.string.admin_quick_templates_label),
        adminAlertPublishedListTitle = res.getString(R.string.admin_alert_published_list_title),
        adminAlertActiveLabel = res.getString(R.string.admin_alert_active_label),
        adminAlertPausedLabel = res.getString(R.string.admin_alert_paused_label),
        adminDeleteAlertBtn = res.getString(R.string.admin_delete_alert_btn),
        heroPillBadge = res.getString(R.string.hero_pill_badge),
        chooseLanguageLabel = res.getString(R.string.choose_language_label),
        arabicLanguageName = res.getString(R.string.arabic_language_name),
        englishLanguageName = res.getString(R.string.english_language_name),
        switchToLanguageDesc = res.getString(R.string.switch_to_language_desc),
        pinInputLabel = res.getString(R.string.pin_input_label),
        confirmPinInputLabel = res.getString(R.string.confirm_pin_input_label),
        validationEmptyName = res.getString(R.string.validation_empty_name),
        validationInvalidEmail = res.getString(R.string.validation_invalid_email),
        validationInvalidPhone = res.getString(R.string.validation_invalid_phone),
        validationPinMismatch = res.getString(R.string.validation_pin_mismatch),
        authConfigMissingError = res.getString(R.string.auth_config_missing_error),
        authUnexpectedCredentialError = res.getString(R.string.auth_unexpected_credential_error),
        authSignInFailedError = res.getString(R.string.auth_sign_in_failed_error),
        adminPasswordLabel = res.getString(R.string.admin_password_label),
        adminPresetBank = res.getString(R.string.admin_preset_bank),
        adminPresetWallet = res.getString(R.string.admin_preset_wallet),
        adminPresetDelivery = res.getString(R.string.admin_preset_delivery),
        adminPresetWhatsappGold = res.getString(R.string.admin_preset_whatsapp_gold),
        errorLoadProfile = res.getString(R.string.error_load_profile),
        errorLoadUsers = res.getString(R.string.error_load_users),
        errorLoadBadges = res.getString(R.string.error_load_badges),
        errorLoadAlerts = res.getString(R.string.error_load_alerts),
        honeypotLogProbeTemplate = res.getString(R.string.honeypot_log_probe_template),
        honeypotLogActivatedTemplate = res.getString(R.string.honeypot_log_activated_template),
        ptsInlineFormat = res.getString(R.string.pts_inline_format),
        securityAssistantTitle = res.getString(R.string.security_assistant_title),
        securityAssistantSubtitle = res.getString(R.string.security_assistant_subtitle),
        securityAssistantWelcome = res.getString(R.string.security_assistant_welcome),
        securityAssistantNewChatBtn = res.getString(R.string.security_assistant_new_chat_btn),
        securityAssistantClearDesc = res.getString(R.string.security_assistant_clear_desc),
        securityAssistantCloseDesc = res.getString(R.string.security_assistant_close_desc),
        securityAssistantTyping = res.getString(R.string.security_assistant_typing),
        securityAssistantRetryBtn = res.getString(R.string.security_assistant_retry_btn),
        securityAssistantContextBadgeFormat = res.getString(R.string.security_assistant_context_badge_format),
        securityAssistantOpenFullChatBtn = res.getString(R.string.security_assistant_open_full_chat_btn),
        securityAssistantScamPrompts = res.getStringArray(R.array.security_assistant_scam_prompts).toList(),
        securityAssistantUserLabel = res.getString(R.string.security_assistant_user_label),
        securityAssistantBotLabel = res.getString(R.string.security_assistant_bot_label),
        securityAssistantEmptyError = res.getString(R.string.security_assistant_empty_error),
        securityAssistantTimeoutError = res.getString(R.string.security_assistant_timeout_error),
        securityAssistantGenericError = res.getString(R.string.security_assistant_generic_error),
        cyberMonitorTitle = res.getString(R.string.cyber_monitor_title),
        cyberMonitorSubtitle = res.getString(R.string.cyber_monitor_subtitle),
        cyberMonitorLiveFeedOn = res.getString(R.string.cyber_monitor_live_feed_on),
        cyberMonitorLiveFeedPaused = res.getString(R.string.cyber_monitor_live_feed_paused),
        cyberMonitorPauseBtn = res.getString(R.string.cyber_monitor_pause_btn),
        cyberMonitorResumeBtn = res.getString(R.string.cyber_monitor_resume_btn),
        cyberMonitorSimulateBtn = res.getString(R.string.cyber_monitor_simulate_btn),
        cyberMonitorFilterAll = res.getString(R.string.cyber_monitor_filter_all),
        cyberMonitorFilterCritical = res.getString(R.string.cyber_monitor_filter_critical),
        cyberMonitorFilterRelevant = res.getString(R.string.cyber_monitor_filter_relevant),
        cyberMonitorSourceFirestoreCloud = res.getString(R.string.cyber_monitor_source_firestore_cloud),
        cyberMonitorSourceFirestoreDevice = res.getString(R.string.cyber_monitor_source_firestore_device),
        cyberMonitorSourceSimulated = res.getString(R.string.cyber_monitor_source_simulated),
        cyberMonitorRelevanceHigh = res.getString(R.string.cyber_monitor_relevance_high),
        cyberMonitorSecuringShieldBtn = res.getString(R.string.cyber_monitor_securing_shield_btn),
        cyberMonitorSaveToCloudBtn = res.getString(R.string.cyber_monitor_save_to_cloud_btn),
        cyberMonitorSavedToCloudBadge = res.getString(R.string.cyber_monitor_saved_to_cloud_badge),
        cyberMonitorTotalCountLabel = res.getString(R.string.cyber_monitor_total_count_label),
        cyberMonitorRelevantCountLabel = res.getString(R.string.cyber_monitor_relevant_count_label),
        cyberMonitorCloudCountLabel = res.getString(R.string.cyber_monitor_cloud_count_label),
        cyberMonitorEmptyFiltered = res.getString(R.string.cyber_monitor_empty_filtered),
        cyberMonitorShowMoreBtn = res.getString(R.string.cyber_monitor_show_more_btn),
        cyberMonitorShowLessBtn = res.getString(R.string.cyber_monitor_show_less_btn),
        cyberMonitorDisclaimer = res.getString(R.string.cyber_monitor_disclaimer),
        smsSendCodeBtn = res.getString(R.string.sms_send_code_btn),
        smsResendCodeBtn = res.getString(R.string.sms_resend_code_btn),
        smsResendCountdownFormat = res.getString(R.string.sms_resend_countdown_format),
        smsSendingProgress = res.getString(R.string.sms_sending_progress),
        smsVerifyingProgress = res.getString(R.string.sms_verifying_progress),
        smsCodeSentBannerFormat = res.getString(R.string.sms_code_sent_banner_format),
        smsAutoRetrievingNote = res.getString(R.string.sms_auto_retrieving_note),
        smsEditPhoneBtn = res.getString(R.string.sms_edit_phone_btn),
        smsSavePhoneBtn = res.getString(R.string.sms_save_phone_btn),
        smsPhoneInputHint = res.getString(R.string.sms_phone_input_hint),
        smsPhoneFormatError = res.getString(R.string.sms_phone_format_error),
        smsVerifySuccessMsg = res.getString(R.string.sms_verify_success_msg),
        smsInvalidCodeError = res.getString(R.string.sms_invalid_code_error),
        smsQuotaExceededError = res.getString(R.string.sms_quota_exceeded_error),
        smsProviderDisabledError = res.getString(R.string.sms_provider_disabled_error),
        smsCollisionError = res.getString(R.string.sms_collision_error),
        smsGenericFailedError = res.getString(R.string.sms_generic_failed_error),
        smsFallbackAvailableNote = res.getString(R.string.sms_fallback_available_note),
        smsCarrierRatesNote = res.getString(R.string.sms_carrier_rates_note),
        smsVerifiedBadge = res.getString(R.string.sms_verified_badge),
        smsUnverifiedBadge = res.getString(R.string.sms_unverified_badge),
        smsVerifyNowBtn = res.getString(R.string.sms_verify_now_btn),
        smsChangePhoneTitle = res.getString(R.string.sms_change_phone_title),
        smsChangePhoneSubtitle = res.getString(R.string.sms_change_phone_subtitle),
        safeBrowser = SafeBrowserStrings(
            urlHint = res.getString(R.string.safe_browser_url_hint),
            openBtn = res.getString(R.string.safe_browser_open_btn),
            adBlockToggle = res.getString(R.string.safe_browser_ad_block_toggle),
            sensitiveFilterToggle = res.getString(R.string.safe_browser_sensitive_filter_toggle),
            adsBlockedFormat = res.getString(R.string.safe_browser_ads_blocked_format),
            sitesBlockedFormat = res.getString(R.string.safe_browser_sites_blocked_format),
            blockedTitle = res.getString(R.string.safe_browser_blocked_title),
            blockedSensitiveReason = res.getString(R.string.safe_browser_blocked_sensitive_reason),
            blockedPhishingReason = res.getString(R.string.safe_browser_blocked_phishing_reason),
            blockedSchemeReason = res.getString(R.string.safe_browser_blocked_scheme_reason),
            backToSafetyBtn = res.getString(R.string.safe_browser_back_to_safety_btn),
            quickBookmarksTitle = res.getString(R.string.safe_browser_quick_bookmarks_title),
            closeDesc = res.getString(R.string.safe_browser_close_desc),
            refreshDesc = res.getString(R.string.safe_browser_refresh_desc),
            backDesc = res.getString(R.string.safe_browser_back_desc),
            forwardDesc = res.getString(R.string.safe_browser_forward_desc),
            activeBadge = res.getString(R.string.safe_browser_active_badge),
            guide = res.getString(R.string.safe_browser_guide),
        ),
        notifPermission = NotificationStrings(
            permissionCardTitle = res.getString(R.string.notif_permission_card_title),
            permissionCardSubtitle = res.getString(R.string.notif_permission_card_subtitle),
            permissionAllowBtn = res.getString(R.string.notif_permission_allow_btn),
            permissionOpenSettingsBtn = res.getString(R.string.notif_permission_open_settings_btn),
            permissionGrantedBadge = res.getString(R.string.notif_permission_granted_badge),
            permissionDeniedBadge = res.getString(R.string.notif_permission_denied_badge),
            permissionGrantedToast = res.getString(R.string.notif_permission_granted_toast),
            permissionDeniedToast = res.getString(R.string.notif_permission_denied_toast),
            testNotificationBtn = res.getString(R.string.notif_test_notification_btn),
            testNotificationTitle = res.getString(R.string.notif_test_notification_title),
            testNotificationBody = res.getString(R.string.notif_test_notification_body),
            testNotificationSentToast = res.getString(R.string.notif_test_notification_sent_toast),
            channelAlertsName = res.getString(R.string.notif_channel_alerts_name),
            channelAlertsDesc = res.getString(R.string.notif_channel_alerts_desc),
            channelUpdatesName = res.getString(R.string.notif_channel_updates_name),
            channelUpdatesDesc = res.getString(R.string.notif_channel_updates_desc),
            badgeUnlockedNotifTitle = res.getString(R.string.notif_badge_unlocked_title),
        ),
    )
}

package com.example

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import androidx.activity.ComponentActivity
import androidx.compose.ui.unit.LayoutDirection
import androidx.test.core.app.ApplicationProvider
import com.example.localization.AppLanguage
import com.example.localization.ArabicStrings
import com.example.localization.Dera3StringResources
import com.example.localization.Dera3Strings
import com.example.localization.EnglishStrings
import com.example.localization.LocalizationManager
import com.example.localization.LocalizedContextWrapper
import com.example.localization.NotificationStrings
import com.example.localization.SafeBrowserStrings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StringResourcesRobolectricTest {

    private fun tailrecFindActivity(context: Context): Activity? {
        var current: Context? = context
        while (current != null) {
            if (current is Activity) return current
            current = (current as? ContextWrapper)?.baseContext
        }
        return null
    }

    private fun assertBundleEquals(clazz: Class<*>, expected: Any, actual: Any) {
        for (field in clazz.declaredFields) {
            field.isAccessible = true
            val expVal = field.get(expected)
            val actVal = field.get(actual)
            when (expVal) {
                is String -> assertEquals("Mismatch for field ${field.name}", expVal, actVal)
                is List<*> -> assertEquals("Mismatch for list field ${field.name}", expVal, actVal)
                is SafeBrowserStrings -> assertBundleEquals(
                    SafeBrowserStrings::class.java,
                    expVal,
                    actVal as SafeBrowserStrings,
                )
                is NotificationStrings -> assertBundleEquals(
                    NotificationStrings::class.java,
                    expVal,
                    actVal as NotificationStrings,
                )
            }
        }
    }

    @Test
    fun `arabic and english xml resources match full Dera3Strings parity`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        val loadedAr = Dera3StringResources.load(context, AppLanguage.AR)
        val loadedEn = Dera3StringResources.load(context, AppLanguage.EN)

        assertBundleEquals(Dera3Strings::class.java, ArabicStrings, loadedAr)
        assertBundleEquals(Dera3Strings::class.java, EnglishStrings, loadedEn)
    }

    @Test
    fun `dynamic localizedContext switches R string and R array between Arabic and English`() {
        val baseContext = ApplicationProvider.getApplicationContext<Context>()

        val arContext = Dera3StringResources.localizedContext(baseContext, AppLanguage.AR)
        assertTrue(arContext is LocalizedContextWrapper)
        assertEquals("درعك الرقمي", arContext.getString(R.string.app_tagline))
        assertEquals("إرسال كود SMS", arContext.getString(R.string.sms_send_code_btn))
        assertEquals(
            "مبروك! حصلت على وسام جديد: الدرع الذهبي",
            arContext.getString(R.string.badge_new_celebration_format, "الدرع الذهبي"),
        )
        assertEquals(
            "يفتح عند 50%",
            LocalizationManager.formatString(
                arContext.getString(R.string.badge_locked_target_format),
                50,
            ),
        )
        assertEquals(12, arContext.resources.getStringArray(R.array.shield_titles).size)
        assertEquals(12, arContext.resources.getStringArray(R.array.shield_subtitles).size)
        assertEquals(
            android.view.View.LAYOUT_DIRECTION_RTL,
            arContext.resources.configuration.layoutDirection,
        )

        val enContext = Dera3StringResources.localizedContext(arContext, AppLanguage.EN)
        assertTrue(enContext is LocalizedContextWrapper)
        assertEquals("Your Digital Shield", enContext.getString(R.string.app_tagline))
        assertEquals("Send SMS Code", enContext.getString(R.string.sms_send_code_btn))
        assertEquals(
            "Congratulations! You earned a new badge: Golden Shield",
            enContext.getString(R.string.badge_new_celebration_format, "Golden Shield"),
        )
        assertEquals("Unlocks at 50%", enContext.getString(R.string.badge_locked_target_format, 50))
        assertEquals(12, enContext.resources.getStringArray(R.array.shield_titles).size)
        assertEquals(12, enContext.resources.getStringArray(R.array.shield_subtitles).size)
        assertEquals(
            android.view.View.LAYOUT_DIRECTION_LTR,
            enContext.resources.configuration.layoutDirection,
        )
        assertEquals(Configuration.SCREENLAYOUT_LAYOUTDIR_LTR, enContext.resources.configuration.screenLayout and Configuration.SCREENLAYOUT_LAYOUTDIR_MASK)
    }

    @Test
    fun `LocalizationManager buildState resolves Android resources dynamically with context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        val arState = LocalizationManager.buildState(AppLanguage.AR, context)
        assertEquals(AppLanguage.AR, arState.language)
        assertEquals(LayoutDirection.Rtl, arState.layoutDirection)
        assertEquals("ماسح التهديدات الفوري", arState.strings.threatScannerTitle)
        assertEquals("مراقب التهديدات السيبرانية", arState.strings.cyberMonitorTitle)

        val enState = LocalizationManager.buildState(AppLanguage.EN, context)
        assertEquals(AppLanguage.EN, enState.language)
        assertEquals(LayoutDirection.Ltr, enState.layoutDirection)
        assertEquals("Threat Scanner", enState.strings.threatScannerTitle)
        assertEquals("Cyber Threat Monitor", enState.strings.cyberMonitorTitle)
    }

    @Test
    fun `localizedContext preserves Activity chain when wrapping Activity context`() {
        val activity = Robolectric.buildActivity(ComponentActivity::class.java).create().get()
        val arActivityContext = Dera3StringResources.localizedContext(activity, AppLanguage.AR)
        val enActivityContext = Dera3StringResources.localizedContext(arActivityContext, AppLanguage.EN)

        val resolvedFromAr = tailrecFindActivity(arActivityContext)
        val resolvedFromEn = tailrecFindActivity(enActivityContext)

        assertNotNull(resolvedFromAr)
        assertSame(activity, resolvedFromAr)
        assertSame(activity, resolvedFromEn)
        assertEquals("Your Digital Shield", enActivityContext.getString(R.string.app_tagline))
        assertEquals("درعك الرقمي", arActivityContext.getString(R.string.app_tagline))
    }
}
